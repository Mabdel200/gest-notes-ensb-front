import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { NotificationService } from '../../core/notification.service';
import { ServicesService } from '../../core/services/services.service';

@Component({
  selector: 'app-update-note-ec',
  templateUrl: './update-note-ec.component.html',
  styleUrl: './update-note-ec.component.scss'
})
export class UpdateNoteEcComponent implements OnInit {
  codeUE!: string;
  codeEC!: string;
  codeEva!: string;
  anneeAca!: number;
  parcours!: string;
  matricule!: string;
  nom!: string;
  noteId!: number;

  public errorMessages = {
    required: 'Ce champ est requis.',
  };

  constructor(private notification: NotificationService, private adminService: ServicesService, private router: Router, private route: ActivatedRoute) {

  }
  form!: FormGroup;
  onForm() {
    this.form = new FormGroup({
      valeur: new FormControl('', [Validators.required])
    })
  }
  ngOnInit(): void {
    this.onForm();
    var slug = this.route.snapshot.params['slug'];
    var str = decodeURIComponent(slug).split('%');
    console.log(str);
    

    this.noteId = Number(str[8])
    this.codeUE = str[1]
    this.codeEC = str[0]
    this.codeEva = str[6]
    this.anneeAca = Number(str[3])
    this.parcours = str[2]
    this.nom = str[5]
    this.matricule = str[4]
    this.form.value.valeur = Number(str[7])
  }

  submit() {
    if (this.form.valid) {
      /* var notes: any = {
         etudiant: this.findEtudiantByMatricule(this.form.value.etudiant),
         valeur: this.form.value.valeur,
         anneeAcademique: this.findTypeAnneeById(Number(this.form.value.annee)),
         cours: this.findcoursById(this.form.value.cours),
         evaluation: this.findTypeEvaluationById( this.form.value.type)
       }*/
      /* // const url = `${apiConfig.admin.notes.cour}`;
      //this.AdminService.saveResource(url, notes).subscribe(
        {
          next: res => {
            this.notification.record()
            this.form.reset();
          },
          error: err => {
            this.notification.error()
   
          }
        }
      );*/

    }
  }



}
